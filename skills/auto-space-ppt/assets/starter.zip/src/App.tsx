import { useCallback, useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { SlideNumberProvider, slides } from './slides'

declare global {
  interface Window { __DECK_READY__?: boolean }
}

const W = 1600
const H = 900
const printMode = new URLSearchParams(window.location.search).has('print')
const autoPrint = new URLSearchParams(window.location.search).has('auto')

function Icon({ name }: { name: 'left' | 'right' | 'grid' | 'full' | 'pdf' }) {
  const common = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const }
  if (name === 'left') return <svg viewBox="0 0 24 24" {...common}><path d="m15 5-7 7 7 7" /></svg>
  if (name === 'right') return <svg viewBox="0 0 24 24" {...common}><path d="m9 5 7 7-7 7" /></svg>
  if (name === 'grid') return <svg viewBox="0 0 24 24" {...common}><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></svg>
  if (name === 'full') return <svg viewBox="0 0 24 24" {...common}><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5" /></svg>
  return <svg viewBox="0 0 24 24" {...common}><path d="M5 3h10l4 4v14H5z" /><path d="M15 3v5h4M8 14h8M8 17h6" /></svg>
}

function getInitialIndex() {
  const parsed = Number(window.location.hash.replace('#', ''))
  return Number.isInteger(parsed) && parsed >= 1 && parsed <= slides.length ? parsed - 1 : 0
}

function useStageScale() {
  const calculate = () => Math.min(window.innerWidth / W, window.innerHeight / H)
  const [scale, setScale] = useState(calculate)
  useEffect(() => {
    const onResize = () => setScale(calculate())
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])
  return scale
}

function PrintDeck() {
  useEffect(() => {
    document.body.classList.add('is-print-view')
    const ready = async () => {
      await document.fonts.ready
      await Promise.all(Array.from(document.images).map((img) => img.complete ? Promise.resolve() : new Promise<void>((resolve) => {
        img.addEventListener('load', () => resolve(), { once: true })
        img.addEventListener('error', () => resolve(), { once: true })
      })))
      window.__DECK_READY__ = true
      if (autoPrint) window.setTimeout(() => window.print(), 500)
    }
    void ready()
    return () => document.body.classList.remove('is-print-view')
  }, [])
  return <main className="print-deck" aria-label="凹凸时空品牌演示模板">
    {slides.map(({ id, component: Slide }, position) => <div className="print-page" key={id}><SlideNumberProvider number={position + 1}><Slide staticMode /></SlideNumberProvider></div>)}
  </main>
}

function Presentation() {
  const [index, setIndex] = useState(getInitialIndex)
  const [direction, setDirection] = useState(1)
  const [overview, setOverview] = useState(false)
  const [controlsVisible, setControlsVisible] = useState(true)
  const [reducedMotion, setReducedMotion] = useState(window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  const scale = useStageScale()
  const wheelLock = useRef(0)
  const touchStart = useRef<number | null>(null)

  useEffect(() => {
    const onHashChange = () => {
      const target = getInitialIndex()
      setIndex((previous) => {
        if (target !== previous) setDirection(target > previous ? 1 : -1)
        return target
      })
    }
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  useEffect(() => {
    let timer = window.setTimeout(() => setControlsVisible(false), 3300)
    const reveal = () => {
      setControlsVisible(true)
      window.clearTimeout(timer)
      timer = window.setTimeout(() => setControlsVisible(false), 3300)
    }
    window.addEventListener('pointermove', reveal)
    return () => { window.clearTimeout(timer); window.removeEventListener('pointermove', reveal) }
  }, [])

  const goTo = useCallback((next: number) => {
    const clamped = Math.max(0, Math.min(slides.length - 1, next))
    setIndex((previous) => {
      if (previous !== clamped) setDirection(clamped > previous ? 1 : -1)
      return clamped
    })
    window.history.replaceState(null, '', `#${clamped + 1}`)
  }, [])

  const next = useCallback(() => setIndex((current) => {
    const target = Math.min(current + 1, slides.length - 1)
    if (target !== current) { setDirection(1); window.history.replaceState(null, '', `#${target + 1}`) }
    return target
  }), [])
  const previous = useCallback(() => setIndex((current) => {
    const target = Math.max(current - 1, 0)
    if (target !== current) { setDirection(-1); window.history.replaceState(null, '', `#${target + 1}`) }
    return target
  }), [])

  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const changed = (event: MediaQueryListEvent) => setReducedMotion(event.matches)
    media.addEventListener('change', changed)
    return () => media.removeEventListener('change', changed)
  }, [])

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.altKey || event.ctrlKey || event.metaKey) return
      if (event.key === 'Escape') { setOverview(false); return }
      if (event.key.toLowerCase() === 'o') { setOverview((value) => !value); return }
      if (event.key.toLowerCase() === 'f') {
        if (document.fullscreenElement) void document.exitFullscreen()
        else void document.documentElement.requestFullscreen()
        return
      }
      if (overview) return
      if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].includes(event.key)) { event.preventDefault(); next() }
      if (['ArrowLeft', 'ArrowUp', 'PageUp'].includes(event.key)) { event.preventDefault(); previous() }
      if (event.key === 'Home') goTo(0)
      if (event.key === 'End') goTo(slides.length - 1)
    }
    const onWheel = (event: WheelEvent) => {
      if (overview || Math.abs(event.deltaY) < 12) return
      const now = Date.now()
      if (now - wheelLock.current < 850) return
      wheelLock.current = now
      if (event.deltaY > 0) next()
      else previous()
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('wheel', onWheel, { passive: true })
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('wheel', onWheel) }
  }, [next, previous, goTo, overview])

  useEffect(() => {
    const ready = async () => {
      await document.fonts.ready
      window.__DECK_READY__ = true
    }
    void ready()
  }, [])

  const slide = slides[index]
  const Slide = slide.component
  const duration = reducedMotion ? 0 : 0.72
  const motionVariants = {
    enter: (dir: number) => ({ opacity: 0, x: dir * 110, scale: 0.965, filter: 'blur(12px)' }),
    center: { opacity: 1, x: 0, scale: 1, filter: 'blur(0px)' },
    exit: (dir: number) => ({ opacity: 0, x: dir * -85, scale: 1.015, filter: 'blur(10px)' }),
  }
  return <div className="app-shell" onTouchStart={(event) => { touchStart.current = event.touches[0]?.clientX ?? null }} onTouchEnd={(event) => {
    if (touchStart.current === null) return
    const delta = (event.changedTouches[0]?.clientX ?? touchStart.current) - touchStart.current
    if (Math.abs(delta) > 65) delta < 0 ? next() : previous()
    touchStart.current = null
  }}>
    <div className="stage">
      <div className="stage__sized" style={{ width: W * scale, height: H * scale }}>
        <div className="stage__canvas" style={{ transform: `scale(${scale})` }}>
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div className="stage__layer" key={slide.id} custom={direction} variants={motionVariants} initial="enter" animate="center" exit="exit" transition={{ duration, ease: [0.22, 1, 0.36, 1] }}>
              <SlideNumberProvider number={index + 1}><Slide staticMode={reducedMotion} /></SlideNumberProvider>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
    <div className={`shortcut-hint ${slide.dark ? '' : 'shortcut-hint--dark'} ${controlsVisible ? '' : 'shortcut-hint--hidden'}`}>← → / SPACE 翻页 · O 目录 · F 全屏</div>
    <div className={`chrome ${controlsVisible ? '' : 'chrome--hidden'}`}>
      <div className="chrome__left"><span className="chrome__label">{String(index + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')} · {slide.title}</span></div>
      <div className="chrome__right">
        <button className="chrome__button" title="上一页" aria-label="上一页" disabled={index === 0} onClick={previous}><Icon name="left" /></button>
        <button className="chrome__button" title="下一页" aria-label="下一页" disabled={index === slides.length - 1} onClick={next}><Icon name="right" /></button>
        <button className="chrome__button" title="目录 (O)" aria-label="目录" onClick={() => setOverview(true)}><Icon name="grid" /></button>
        <button className="chrome__button" title="全屏 (F)" aria-label="全屏" onClick={() => { if (document.fullscreenElement) void document.exitFullscreen(); else void document.documentElement.requestFullscreen() }}><Icon name="full" /></button>
        <button className="chrome__button chrome__pdf" title="打开 PDF 打印视图" onClick={() => window.open(`${window.location.pathname}?print=1&auto=1`, '_blank')}><Icon name="pdf" /> 导出 PDF</button>
      </div>
    </div>
    <div className="progress-track" role="progressbar" aria-valuenow={index + 1} aria-valuemin={1} aria-valuemax={slides.length}><div style={{ width: `${(index + 1) / slides.length * 100}%` }} /></div>
    {overview && <div className="overview" role="dialog" aria-label="演示目录">
      <div className="overview__top"><h2>演示目录 <small> / {slides.length} SLIDES</small></h2><button className="overview__close" onClick={() => setOverview(false)}>关闭 ESC</button></div>
      <div className="overview__grid">{slides.map((item, position) => <button key={item.id} className={`overview-card ${item.dark ? '' : 'overview-card--light'} ${position === index ? 'overview-card--active' : ''}`} onClick={() => { goTo(position); setOverview(false) }}><span className="overview-card__no">{String(position + 1).padStart(2, '0')}</span><span className="overview-card__category">{item.category}</span><h3>{item.title}</h3></button>)}</div>
    </div>}
  </div>
}

export default function App() { return printMode ? <PrintDeck /> : <Presentation /> }
