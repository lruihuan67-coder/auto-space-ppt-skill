import { createContext, useContext, useEffect, useState, type ComponentType, type ReactNode, type CSSProperties } from 'react'
import { motion } from 'motion/react'
import coverArchitecture from './assets/cover-architecture.png?inline'
import blueRibbon from './assets/blue-ribbon.png?inline'
import industrialRobot from './assets/industrial-robot.png?inline'
import controlRoom from './assets/control-room.png?inline'
import engineerTeam from './assets/engineer-team.png?inline'
import productUiDemo from './assets/product-ui-demo.png?inline'
import photoSmartFactory from './assets/photo-smart-factory.jpg?inline'
import photoVisionInspection from './assets/photo-vision-inspection.jpg?inline'
import photoEngineers from './assets/photo-engineers.jpg?inline'
import photoWarehouse from './assets/photo-warehouse.jpg?inline'
import photoEnergyRoom from './assets/photo-energy-room.jpg?inline'
import photoMaintenance from './assets/photo-maintenance.jpg?inline'
import logoWhite from './assets/logo-white.png?inline'
import logoBlue from './assets/logo-blue.png?inline'
import partnerLaurel from './assets/partner-laurel.svg?inline'

export type SlideProps = { staticMode: boolean }
export type SlideDefinition = {
  id: string
  title: string
  category: string
  dark: boolean
  component: ComponentType<SlideProps>
}

const SlideNumberContext = createContext<number | null>(null)

export function SlideNumberProvider({ number, children }: { number: number; children: ReactNode }) {
  return <SlideNumberContext.Provider value={number}>{children}</SlideNumberContext.Provider>
}

type RevealProps = SlideProps & {
  children: ReactNode
  className?: string
  delay?: number
  from?: 'up' | 'left' | 'right'
}

function Reveal({ children, className, delay = 0, from = 'up', staticMode }: RevealProps) {
  if (staticMode) return <div className={className}>{children}</div>
  const offset = from === 'left' ? { x: -52, y: 0 } : from === 'right' ? { x: 52, y: 0 } : { x: 0, y: 46 }
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, filter: 'blur(9px)', ...offset }}
      animate={{ opacity: 1, filter: 'blur(0px)', x: 0, y: 0 }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

function Brand({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  if (light) return <img className={`brand brand--white ${compact ? 'brand--compact' : ''}`} src={logoWhite} alt="凹凸时空 AUTO SPACE" />
  return <img className={`brand brand--color ${compact ? 'brand--compact' : ''}`} src={logoBlue} alt="凹凸时空 AUTO SPACE" />
}

function TinyIndex({ number, light = false }: { number: number; light?: boolean }) {
  const current = useContext(SlideNumberContext) ?? number
  return <span className={`tiny-index ${light ? 'tiny-index--light' : ''}`}>{String(current).padStart(2, '0')} / {slides.length}</span>
}

type PartnerLogo = { mark: string; label: string; color: string; src?: string }

// Replace each placeholder with an authorized logo asset before external use.
// An imported data URL (for example, an asset imported with ?inline) also works here.
const partnerLogos: PartnerLogo[] = [
  { mark: 'NOVA', label: '智造平台', color: '#83ba37' }, { mark: '云阶', label: '数字技术', color: '#25a7db' }, { mark: 'AIX', label: '工业智能', color: '#283a57' }, { mark: '同源', label: '产业协作', color: '#39af8d' },
  { mark: 'MOTIO', label: '先进制造', color: '#ef8656' }, { mark: '知序', label: '企业服务', color: '#e75562' }, { mark: 'VIVID', label: '创意科技', color: '#f4af21' }, { mark: '筑能', label: '能源管理', color: '#e1653a' },
  { mark: 'CENTRA', label: '数据系统', color: '#202e44' }, { mark: '橙域', label: '智慧园区', color: '#ef8936' }, { mark: '58°', label: '业务网络', color: '#23b5ae' }, { mark: 'MATRIX', label: '信息科技', color: '#46a694' },
  { mark: 'LINK', label: '连接服务', color: '#f3a22d' }, { mark: 'keep+', label: '健康科技', color: '#5d548c' }, { mark: '莓点', label: '消费科技', color: '#d73e78' }, { mark: '蓝图', label: '研发平台', color: '#2477b9' },
  { mark: '源码', label: '软件工程', color: '#2466b0' }, { mark: 'ECO', label: '绿色科技', color: '#6aac53' }, { mark: '航线', label: '供应链', color: '#eaa626' }, { mark: 'GRID', label: '工业互联', color: '#526fb6' },
]

function PartnerMark({ partner, index }: { partner: PartnerLogo; index: number }) {
  if (partner.src) return <img className="partner-logo-image" src={partner.src} alt={partner.label} />
  return <span className={`partner-mark partner-mark--${index % 8}`} style={{ '--mark-color': partner.color } as CSSProperties} aria-label={`${partner.label} Logo 占位`}>
    <i aria-hidden="true" /><span className="partner-mark__word"><strong>{partner.mark}</strong><small>{partner.label}</small></span>
  </span>
}

function PartnerDisclaimer({ light = false }: { light?: boolean }) {
  return <span className={`partner-disclaimer ${light ? 'partner-disclaimer--light' : ''}`}>示意 Logo 与数字 · 对外使用前替换为已核实内容</span>
}

function Cover({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-cover">
      <div className="slide-cover__image" style={{ backgroundImage: `url(${coverArchitecture})` }} />
      <div className="slide-cover__shade" />
      <div className="slide-cover__beam" />
      <div className="slide-cover__top"><Brand light /><span>BRAND PRESENTATION · 2026</span></div>
      <div className="slide-cover__copy">
        <Reveal staticMode={staticMode} delay={0.15} className="eyebrow eyebrow--light">凹凸时空 / AUTO SPACE</Reveal>
        <Reveal staticMode={staticMode} delay={0.29}><h1>让 AI 成为<br /><em>真正的生产力</em></h1></Reveal>
        <Reveal staticMode={staticMode} delay={0.55}><p>面向产业现场的人工智能解决方案</p></Reveal>
      </div>
      <div className="slide-cover__bottom"><span>AI 改变行业未来</span><span>汇报团队：凹凸时空</span><span>汇报日期：2026.10.22</span></div>
    </section>
  )
}

function Agenda({ staticMode }: SlideProps) {
  const items = [
    ['01', '项目背景', '从业务问题与实际场景出发'],
    ['02', '方案与能力', '连接模型、数据和工作流程'],
    ['03', '数据与案例', '用图表和影像解释价值'],
    ['04', '总结与行动', '形成可执行的下一步'],
  ]
  return (
    <section className="slide slide-agenda">
      <div className="slide-agenda__left">
        <Brand light compact />
        <Reveal staticMode={staticMode} delay={0.12} className="slide-agenda__heading"><span>CONTENTS</span><h2>从问题<br />到结果</h2></Reveal>
        <span className="slide-agenda__foot">AUTO SPACE / CONTENTS</span>
      </div>
      <div className="slide-agenda__list">
        {items.map(([no, title, desc], i) => (
          <Reveal staticMode={staticMode} from="right" delay={0.16 + i * 0.12} className="agenda-row" key={no}>
            <span className="agenda-row__no">{no}</span>
            <div><h3>{title}</h3><p>{desc}</p></div>
            <span className="agenda-row__arrow">↗</span>
          </Reveal>
        ))}
      </div>
    </section>
  )
}

function SectionOne({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-section" style={{ backgroundImage: `url(${blueRibbon})` }}>
      <div className="slide-section__shade" />
      <div className="slide-section__number" aria-hidden="true">01</div>
      <div className="slide-section__top"><Brand light compact /><span>CHAPTER 01 / BUSINESS SCENARIO</span></div>
      <div className="slide-section__copy">
        <Reveal staticMode={staticMode} delay={0.12} className="eyebrow eyebrow--light">01 / 场景先行</Reveal>
        <Reveal staticMode={staticMode} delay={0.26}><h2>从真实场景<br />开始</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.55}><p>技术的起点是业务问题，终点是稳定可用的工作方式。</p></Reveal>
      </div>
      <TinyIndex number={3} light />
    </section>
  )
}

function Statement({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-statement">
      <div className="slide-statement__side">AUTO SPACE — PERSPECTIVE</div>
      <div className="slide-statement__rule" />
      <div className="slide-statement__content">
        <Reveal staticMode={staticMode} delay={0.16} className="eyebrow">核心观点</Reveal>
        <Reveal staticMode={staticMode} delay={0.28}><h2>AI 的价值，<br /><em>从现场开始。</em></h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.6}><p>每一次技术投入，都应该指向具体的业务改善。</p></Reveal>
      </div>
      <Brand compact />
      <TinyIndex number={4} />
    </section>
  )
}

function PhotoStory({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-photo">
      <div className="slide-photo__copy">
        <Reveal staticMode={staticMode} delay={0.1} className="eyebrow">INDUSTRIAL INTELLIGENCE</Reveal>
        <Reveal staticMode={staticMode} delay={0.25}><h2>技术进入现场，<br />才有机会<br /><em>改变现场。</em></h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.57}><p>从设备数据、知识经验到工作流程，选择能产生实际价值的切入点。</p></Reveal>
        <Brand compact />
      </div>
      <motion.div
        className="slide-photo__image"
        style={{ backgroundImage: `url(${industrialRobot})` }}
        initial={staticMode ? false : { clipPath: 'inset(0 0 0 100%)', scale: 1.07 }}
        animate={{ clipPath: 'inset(0 0 0 0%)', scale: 1 }}
        transition={{ duration: 1.15, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
      />
      <div className="slide-photo__caption">概念场景图 / 非实际项目现场</div>
      <TinyIndex number={7} />
    </section>
  )
}

function Capabilities({ staticMode }: SlideProps) {
  const columns = [
    ['01', '场景洞察', '梳理业务目标，识别值得投入的 AI 场景。'],
    ['02', '模型工程', '整合算法、数据与知识，构建可用能力。'],
    ['03', '场景交付', '把能力嵌入流程，持续观察和优化效果。'],
  ]
  return (
    <section className="slide slide-capabilities">
      <div className="slide-header slide-header--dark"><Brand compact /><span>CAPABILITIES / 服务能力</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>以全链条能力<br />支撑企业 AI 转型</h2></Reveal>
      <div className="capability-grid">
        {columns.map(([no, title, body], i) => (
          <Reveal staticMode={staticMode} delay={0.28 + i * 0.14} className="capability" key={no}>
            <span className="capability__no">{no}</span>
            <span className="capability__line" />
            <h3>{title}</h3>
            <p>{body}</p>
          </Reveal>
        ))}
      </div>
      <TinyIndex number={8} />
    </section>
  )
}

function Process({ staticMode }: SlideProps) {
  const steps = [
    ['01', '发现', '明确业务问题'],
    ['02', '设计', '确定验证方案'],
    ['03', '验证', '试点运行复盘'],
    ['04', '部署', '进入日常流程'],
  ]
  return (
    <section className="slide slide-process">
      <div className="slide-process__wash" />
      <div className="slide-header slide-header--light"><Brand light compact /><span>DELIVERY PATH / 交付路径</span></div>
      <Reveal staticMode={staticMode} delay={0.15}><h2>让试点走向长期应用</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.37}><p className="slide-process__intro">每一步都有明确产出，便于协作、评估与复盘。</p></Reveal>
      <div className="process-track">
        <svg viewBox="0 0 1320 40" preserveAspectRatio="none" aria-hidden="true">
          <motion.path d="M 14 20 H 1306" stroke="#80BFFF" strokeWidth="2" fill="none" initial={staticMode ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.7, delay: 0.52, ease: 'easeInOut' }} />
        </svg>
        {steps.map(([no, title, desc], i) => (
          <Reveal staticMode={staticMode} delay={0.5 + i * 0.18} className="process-step" key={no}>
            <span className="process-step__number">{no}</span>
            <span className="process-step__dot" />
            <h3>{title}</h3>
            <p>{desc}</p>
          </Reveal>
        ))}
      </div>
      <TinyIndex number={12} light />
    </section>
  )
}

function Architecture({ staticMode }: SlideProps) {
  const layers = [
    ['04', '业务应用', '让一线人员能直接使用'],
    ['03', '流程编排', '连接系统与执行步骤'],
    ['02', '智能能力', '模型、知识与工具协同'],
    ['01', '数据基础', '接入可信业务信息'],
  ]
  return (
    <section className="slide slide-architecture">
      <div className="slide-header slide-header--dark"><Brand compact /><span>SOLUTION ARCHITECTURE</span></div>
      <div className="architecture-copy">
        <Reveal staticMode={staticMode} delay={0.13} className="eyebrow">解决方案架构</Reveal>
        <Reveal staticMode={staticMode} delay={0.29}><h2>让 AI 能力<br />进入业务流程</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.52}><p>以业务应用为目标，向下连接流程、智能能力与数据基础。</p></Reveal>
      </div>
      <div className="architecture-stack">
        {layers.map(([no, title, desc], i) => (
          <Reveal staticMode={staticMode} from="right" delay={0.28 + i * 0.14} className={`architecture-layer architecture-layer--${i}`} key={no}>
            <span>{no}</span><h3>{title}</h3><p>{desc}</p>
          </Reveal>
        ))}
      </div>
      <TinyIndex number={13} />
    </section>
  )
}

function LogicArgument({ staticMode }: SlideProps) {
  const steps = [
    { no: '01', label: '事实', title: '现场数据分散', detail: '关键状态需要跨系统查找。' },
    { no: '02', label: '问题', title: '判断出现延迟', detail: '变化发生后，人员难以及时发现。' },
    { no: '03', label: '机制', title: '集中识别变化', detail: '统一接入信号并标记异常。' },
    { no: '04', label: '结论', title: '把提示送到现场', detail: '在决策节点给出可执行建议。' },
  ]
  return <section className="slide slide-logic-argument">
    <div className="slide-header slide-header--dark"><Brand compact /><span>LOGIC / 论证链</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading"><span className="eyebrow">论证链</span><h2>一条结论，四层依据</h2><p>适合把事实、问题、解决机制和最终判断放在同一条线上。</p></Reveal>
    <div className="logic-argument__track">
      {steps.map((step, index) => <Reveal staticMode={staticMode} delay={0.28 + index * 0.15} className={`logic-argument__step logic-argument__step--${index}`} key={step.no}>
        <div className="logic-argument__top"><span>{step.no}</span><em>{step.label}</em></div>
        <h3>{step.title}</h3><p>{step.detail}</p>
      </Reveal>)}
    </div>
    <div className="logic-argument__conclusion"><b>表达方式</b><strong>先给依据，再说判断。</strong><span>把每一步的证据换成你自己的项目内容。</span></div>
    <span className="logic-note">示例逻辑 / 正式使用时替换节点文案</span><TinyIndex number={24} />
  </section>
}

function LogicDecisionTree({ staticMode }: SlideProps) {
  const outcomes = [
    { title: '高频且价值明确', detail: '进入首批试点', className: 'logic-tree__outcome--one' },
    { title: '发生频次较低', detail: '先保留观察', className: 'logic-tree__outcome--two' },
    { title: '可以补充采集', detail: '完善数据接入', className: 'logic-tree__outcome--three' },
    { title: '暂时无法补采', detail: '调整候选场景', className: 'logic-tree__outcome--four' },
  ]
  return <section className="slide slide-logic-tree">
    <div className="slide-header slide-header--dark"><Brand compact /><span>LOGIC / 决策树</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading"><span className="eyebrow">决策树</span><h2>条件不同，路径不同</h2><p>适合展示准入条件、例外分支和下一步处理。</p></Reveal>
    <svg className="logic-tree__lines" viewBox="0 0 1600 900" aria-hidden="true"><path d="M 428 510 H 500 V 365 H 610 M 500 510 V 645 H 610 M 910 365 H 982 V 292 H 1088 M 982 365 V 423 H 1088 M 910 645 H 982 V 575 H 1088 M 982 645 V 710 H 1088" fill="none" stroke="#8bb9e5" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
    <Reveal staticMode={staticMode} delay={0.25} className="logic-tree__root"><small>起点问题</small><h3>是否具备<br />可用数据？</h3></Reveal>
    <Reveal staticMode={staticMode} delay={0.39} className="logic-tree__branch logic-tree__branch--yes"><span>YES</span><h3>数据可验证</h3><p>再判断发生频次与价值</p></Reveal>
    <Reveal staticMode={staticMode} delay={0.45} className="logic-tree__branch logic-tree__branch--no"><span>NO</span><h3>数据不稳定</h3><p>先判断能否补充采集</p></Reveal>
    {outcomes.map((item, index) => <Reveal staticMode={staticMode} delay={0.53 + index * 0.09} className={`logic-tree__outcome ${item.className}`} key={item.title}><h3>{item.title}</h3><p>{item.detail}</p></Reveal>)}
    <span className="logic-note">示例判断条件 / 可按真实业务增减分支</span><TinyIndex number={25} />
  </section>
}

function LogicCauseMap({ staticMode }: SlideProps) {
  const causes = [
    { no: '01', category: '信息', title: '状态分散', detail: '关键变化没有统一呈现。' },
    { no: '02', category: '流程', title: '交接不清', detail: '异常出现后缺少明确处理路径。' },
    { no: '03', category: '协作', title: '反馈滞后', detail: '处理结果未及时回到下一次判断。' },
  ]
  return <section className="slide slide-logic-cause">
    <div className="slide-header slide-header--light"><Brand light compact /><span>LOGIC / 因果拆解</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading logic-heading--light"><span className="eyebrow eyebrow--light">因果拆解</span><h2>把现象拆成可处理的原因</h2><p>先写清楚要解释的现象，再按类别列出可验证的原因。</p></Reveal>
    <div className="logic-cause__problem"><span>待解释的现象</span><strong>现场响应慢</strong><small>示例问题陈述</small></div>
    <svg className="logic-cause__lines" viewBox="0 0 1600 900" aria-hidden="true"><path d="M 470 572 H 535 V 410 H 585 M 535 572 H 585 M 535 572 V 734 H 585" fill="none" stroke="#6daffc" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
    <div className="logic-cause__rows">{causes.map((cause, index) => <Reveal staticMode={staticMode} delay={0.3 + index * 0.15} className="logic-cause__row" key={cause.no}><span>{cause.no}</span><div><small>{cause.category}</small><h3>{cause.title}</h3></div><p>{cause.detail}</p></Reveal>)}</div>
    <span className="logic-note logic-note--light">示例原因 / 请用访谈、数据或现场记录验证</span><TinyIndex number={26} light />
  </section>
}

function LogicLoop({ staticMode }: SlideProps) {
  const stages = [
    ['01', '发现信号', '识别值得处理的变化', 'logic-loop__stage--top'],
    ['02', '提出建议', '给出可执行的下一步', 'logic-loop__stage--right'],
    ['03', '记录执行', '让处理过程可追踪', 'logic-loop__stage--bottom'],
    ['04', '复盘修正', '把结果带回判断规则', 'logic-loop__stage--left'],
  ]
  return <section className="slide slide-logic-loop">
    <div className="slide-header slide-header--dark"><Brand compact /><span>LOGIC / 迭代闭环</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading"><span className="eyebrow">迭代闭环</span><h2>方案在使用中持续改进</h2><p>适合说明运行后的反馈如何回到下一轮设计。</p></Reveal>
    <svg className="logic-loop__ring" viewBox="0 0 1600 900" aria-hidden="true"><circle cx="800" cy="552" r="230" fill="none" stroke="#d8eaf9" strokeWidth="56" /><path d="M 866 330 A 230 230 0 0 1 1022 486 M 1022 618 A 230 230 0 0 1 866 774 M 734 774 A 230 230 0 0 1 578 618 M 578 486 A 230 230 0 0 1 734 330" fill="none" stroke="#0d7cfd" strokeWidth="4" strokeLinecap="round" /><path d="M 1012 477 L 1022 486 L 1010 486 M 590 626 L 578 618 L 580 631" fill="none" stroke="#0d7cfd" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg>
    <div className="logic-loop__center"><span>CONTINUOUS</span><strong>持续<br />优化</strong><small>结果回到下一轮判断</small></div>
    {stages.map(([no, title, detail, className], index) => <Reveal staticMode={staticMode} delay={0.3 + index * 0.14} className={`logic-loop__stage ${className}`} key={no}><span>{no}</span><div><h3>{title}</h3><p>{detail}</p></div></Reveal>)}
    <span className="logic-note">示例闭环 / 可替换为产品、服务或项目运行机制</span><TinyIndex number={27} />
  </section>
}

function LogicFunnel({ staticMode }: SlideProps) {
  const levels = [
    { no: '01', title: '候选场景', detail: '收集一线需求和业务机会' },
    { no: '02', title: '价值判断', detail: '确认问题是否高频且可量化' },
    { no: '03', title: '实施条件', detail: '检查数据、流程与责任人' },
    { no: '04', title: '首批试点', detail: '留下可验证的少数场景' },
  ]
  return <section className="slide slide-logic-funnel">
    <div className="slide-header slide-header--dark"><Brand compact /><span>LOGIC / 漏斗筛选</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading"><span className="eyebrow">漏斗筛选</span><h2>从候选场景筛到首批试点</h2><p>适合解释筛选标准如何逐步收窄选择范围。</p></Reveal>
    <div className="logic-funnel__stack">{levels.map((level, index) => <Reveal staticMode={staticMode} delay={0.25 + index * 0.13} className={`logic-funnel__level logic-funnel__level--${index}`} key={level.no}><span>{level.no}</span><strong>{level.title}</strong></Reveal>)}</div>
    <div className="logic-funnel__criteria">{levels.map((level, index) => <Reveal staticMode={staticMode} delay={0.3 + index * 0.13} className="logic-funnel__criterion" key={level.no}><span>{level.no}</span><div><h3>{level.title}</h3><p>{level.detail}</p></div></Reveal>)}</div>
    <span className="logic-note">示例标准 / 使用前按项目目标修改筛选条件</span><TinyIndex number={28} />
  </section>
}

function LogicSwimlane({ staticMode }: SlideProps) {
  const tasks = [
    { label: '提出场景', lane: 'business', col: 0 }, { label: '确认目标', lane: 'business', col: 1 },
    { label: '核对数据', lane: 'tech', col: 1 }, { label: '构建方案', lane: 'tech', col: 2 },
    { label: '现场试点', lane: 'delivery', col: 2 }, { label: '进入运行', lane: 'delivery', col: 3 },
  ]
  return <section className="slide slide-logic-swimlane">
    <div className="slide-header slide-header--dark"><Brand compact /><span>LOGIC / 泳道协作</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="logic-heading"><span className="eyebrow">泳道协作</span><h2>跨团队任务如何接力</h2><p>按责任方展示工作顺序与交接点，适合项目计划和服务流程。</p></Reveal>
    <div className="logic-swimlane__board">
      <div className="logic-swimlane__lane logic-swimlane__lane--business"><strong>业务团队</strong><small>提出需求 · 确认目标</small></div>
      <div className="logic-swimlane__lane logic-swimlane__lane--tech"><strong>技术团队</strong><small>核对数据 · 形成方案</small></div>
      <div className="logic-swimlane__lane logic-swimlane__lane--delivery"><strong>交付团队</strong><small>现场验证 · 日常运行</small></div>
      <svg className="logic-swimlane__lines" viewBox="0 0 1400 480" aria-hidden="true"><defs><marker id="swimlane-arrow" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M 1 1 L 8 5 L 1 9" fill="none" stroke="#54a4ef" strokeWidth="1.6" /></marker></defs><path d="M 530 80 H 608 M 715 124 V 193 M 810 240 H 888 M 995 284 V 353 M 1090 400 H 1168" fill="none" stroke="#54a4ef" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" markerEnd="url(#swimlane-arrow)" /></svg>
      {tasks.map((task, index) => <Reveal staticMode={staticMode} delay={0.27 + index * 0.1} className={`logic-swimlane__task logic-swimlane__task--${task.lane} logic-swimlane__task--col-${task.col}`} key={task.label}><span>{String(index + 1).padStart(2, '0')}</span><strong>{task.label}</strong></Reveal>)}
    </div>
    <span className="logic-note">示例分工 / 可调整泳道、任务与交接顺序</span><TinyIndex number={29} />
  </section>
}

function AnimatedNumber({ staticMode, value }: { staticMode: boolean; value: number }) {
  const [display, setDisplay] = useState(staticMode ? value : 0)
  useEffect(() => {
    if (staticMode) return
    const start = performance.now()
    let frame = 0
    const tick = (now: number) => {
      const progress = Math.min((now - start) / 1750, 1)
      setDisplay(Math.round(value * (1 - Math.pow(1 - progress, 3))))
      if (progress < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [staticMode, value])
  return <>{display}</>
}

function Metric({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-metric" style={{ backgroundImage: `url(${blueRibbon})` }}>
      <div className="slide-metric__shade" />
      <div className="slide-header slide-header--light"><Brand light compact /><span>DATA HIGHLIGHT / 示例数据</span></div>
      <div className="metric-copy">
        <Reveal staticMode={staticMode} delay={0.13} className="eyebrow eyebrow--light">一页聚焦一个关键指标</Reveal>
        <Reveal staticMode={staticMode} delay={0.32} className="metric-value"><AnimatedNumber staticMode={staticMode} value={68} /><span>%</span></Reveal>
        <Reveal staticMode={staticMode} delay={0.55}><h2>试点流程自动化覆盖率</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.72}><p>用一个指标说明变化，再解释它与业务目标的关系。</p></Reveal>
      </div>
      <div className="sample-note">* 本页为版式示例，数值不代表公司实际业绩</div>
      <TinyIndex number={14} light />
    </section>
  )
}

function Comparison({ staticMode }: SlideProps) {
  const before = ['信息分散在文档和个人经验中', '重复任务依赖人工处理', '难以持续追踪执行效果']
  const after = ['知识集中管理，按需检索', '常规任务由智能流程协助', '运行数据支持持续优化']
  return (
    <section className="slide slide-comparison">
      <div className="comparison-left">
        <span className="eyebrow">BEFORE / 当前方式</span>
        <Reveal staticMode={staticMode} delay={0.15}><h2>人去找信息</h2></Reveal>
        <div className="comparison-list">{before.map((item, i) => <Reveal staticMode={staticMode} delay={0.28 + i * 0.12} key={item}><p><span>0{i + 1}</span>{item}</p></Reveal>)}</div>
      </div>
      <div className="comparison-right">
        <span className="eyebrow eyebrow--light">AFTER / 目标方式</span>
        <Reveal staticMode={staticMode} from="right" delay={0.2}><h2>信息主动服务</h2></Reveal>
        <div className="comparison-list">{after.map((item, i) => <Reveal staticMode={staticMode} from="right" delay={0.33 + i * 0.12} key={item}><p><span>0{i + 1}</span>{item}</p></Reveal>)}</div>
      </div>
      <TinyIndex number={15} light />
    </section>
  )
}

function Chart({ staticMode }: SlideProps) {
  const values = [
    { q: 'Q1', value: 22 },
    { q: 'Q2', value: 40 },
    { q: 'Q3', value: 57 },
    { q: 'Q4', value: 74 },
  ]
  return (
    <section className="slide slide-chart">
      <div className="slide-header slide-header--dark"><Brand compact /><span>DATA STORY / 示例数据</span></div>
      <Reveal staticMode={staticMode} delay={0.13}><h2>让趋势比表格更早说话</h2></Reveal>
      <div className="chart-layout">
        <div className="chart-plot">
          <div className="chart-grid"><span>80</span><span>60</span><span>40</span><span>20</span><span>0</span></div>
          <div className="chart-bars">
            {values.map(({ q, value }, i) => (
              <div className="chart-bar-group" key={q}>
                <div className="chart-bar-area">
                  {staticMode ? <div className={`chart-bar ${i === 3 ? 'chart-bar--active' : ''}`} style={{ height: `${value / 80 * 100}%` }} /> : (
                    <motion.div className={`chart-bar ${i === 3 ? 'chart-bar--active' : ''}`} style={{ height: `${value / 80 * 100}%` }} initial={{ scaleY: 0, opacity: 0.4 }} animate={{ scaleY: 1, opacity: 1 }} transition={{ duration: 0.85, delay: 0.33 + i * 0.14, ease: [0.22, 1, 0.36, 1] }} />
                  )}
                  <span className="chart-bar-value">{value}</span>
                </div>
                <span className="chart-bar-label">{q}</span>
              </div>
            ))}
          </div>
        </div>
        <Reveal staticMode={staticMode} from="right" delay={0.58} className="chart-insight"><span>KEY INSIGHT</span><strong>Q4</strong><p>指标持续上升。用简短结论解释变化，而不是重复读数。</p></Reveal>
      </div>
      <div className="sample-note sample-note--dark">* 演示数据，正式使用时请替换为实际指标与结论</div>
      <TinyIndex number={16} />
    </section>
  )
}

function Plan({ staticMode }: SlideProps) {
  const rows = [
    ['01', '需求确认', '梳理业务场景与目标', '需求清单'],
    ['02', '方案验证', '构建原型并开展试点', '验证报告'],
    ['03', '系统部署', '完成集成、培训与交付', '上线方案'],
    ['04', '持续优化', '跟踪使用效果并复盘', '运营报告'],
  ]
  return (
    <section className="slide slide-plan">
      <div className="slide-header slide-header--dark"><Brand compact /><span>PROJECT ROADMAP</span></div>
      <Reveal staticMode={staticMode} delay={0.14}><h2>项目推进总览</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.3}><p className="slide-plan__intro">把阶段、任务与交付物放在同一张清晰的时间表里。</p></Reveal>
      <div className="plan-table">
        <div className="plan-table__head"><span>阶段</span><span>工作重点</span><span>预期产出</span></div>
        {rows.map(([no, phase, task, output], i) => (
          <Reveal staticMode={staticMode} delay={0.36 + i * 0.12} className="plan-table__row" key={no}>
            <span><b>{no}</b>{phase}</span><span>{task}</span><span>{output}</span>
          </Reveal>
        ))}
      </div>
      <TinyIndex number={20} />
    </section>
  )
}

function PlainContent({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-plain-content">
      <div className="slide-header slide-header--dark"><Brand compact /><span>CONTENT / 正文内容</span></div>
      <div className="plain-content__main">
        <Reveal staticMode={staticMode} delay={0.12} className="eyebrow">01 / 问题定义</Reveal>
        <Reveal staticMode={staticMode} delay={0.24}><h2>从业务问题<br />定义 AI 机会</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.48}><p>在决定采用哪种技术之前，先明确要改善的流程、服务对象与衡量方式。问题定义越清楚，后续验证就越聚焦。</p></Reveal>
        <Reveal staticMode={staticMode} delay={0.63}><p>这类页面适合放置项目背景、研究发现或方法说明。正文可按实际内容增减，但应保持足够留白与清晰的段落层级。</p></Reveal>
      </div>
      <div className="plain-content__aside">
        <Reveal staticMode={staticMode} from="right" delay={0.52}><span>KEY THOUGHT</span><strong>先定义价值，<br />再选择技术。</strong><i /></Reveal>
      </div>
      <TinyIndex number={5} />
    </section>
  )
}

function BulletContent({ staticMode }: SlideProps) {
  const points = [
    ['01', '目标具体', '把宽泛的转型愿景拆解为可观察的业务问题。'],
    ['02', '场景优先', '优先选择高频、清晰且具备数据基础的环节。'],
    ['03', '试点验证', '在受控范围内验证效果与使用体验。'],
    ['04', '持续迭代', '让反馈、数据与业务负责人共同推动优化。'],
  ]
  return (
    <section className="slide slide-bullets">
      <div className="slide-header slide-header--dark"><Brand compact /><span>KEY POINTS / 要点列表</span></div>
      <Reveal staticMode={staticMode} delay={0.14}><h2>把复杂议题<br />讲成四个清晰动作</h2></Reveal>
      <div className="bullet-content__list">
        {points.map(([no, heading, body], i) => <Reveal staticMode={staticMode} delay={0.31 + i * 0.1} className="bullet-content__item" key={no}>
          <span>{no}</span><div><h3>{heading}</h3><p>{body}</p></div>
        </Reveal>)}
      </div>
      <div className="bullet-content__number" aria-hidden="true">04</div>
      <TinyIndex number={6} />
    </section>
  )
}

function EditorialSplit({ staticMode }: SlideProps) {
  const columns = [
    ['01', '改善什么', '从耗时、差错与协作阻力中，选出最值得解决的一个问题。先把目标写清楚，团队才会对成功有共同理解。'],
    ['02', '怎样判断有效', '在试点前确定观察范围与衡量方式。把流程变化、使用反馈和业务结果放在一起看，避免只展示技术能力。'],
  ]
  return (
    <section className="slide slide-editorial">
      <div className="slide-header slide-header--dark"><Brand compact /><span>EDITORIAL / 双栏论述</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>企业 AI 转型，<br />先回答两个问题</h2></Reveal>
      <div className="editorial-columns">
        {columns.map(([no, title, body], i) => <Reveal staticMode={staticMode} delay={0.31 + i * 0.16} className="editorial-column" key={no}>
          <span>{no} / KEY QUESTION</span><h3>{title}</h3><p>{body}</p>
        </Reveal>)}
      </div>
      <TinyIndex number={7} />
    </section>
  )
}

function ProjectBrief({ staticMode }: SlideProps) {
  const fields = [
    ['业务目标', '缩短信息查找与响应时间'],
    ['使用场景', '一线人员在现有流程中直接调用'],
    ['数据基础', '先确认知识来源、质量与更新责任'],
    ['验证方式', '记录使用情况，收集真实问题与反馈'],
  ]
  return (
    <section className="slide slide-brief">
      <div className="slide-header slide-header--dark"><Brand compact /><span>PROJECT BRIEF / 项目简报</span></div>
      <div className="brief-copy">
        <Reveal staticMode={staticMode} delay={0.12} className="eyebrow">从需求到任务</Reveal>
        <Reveal staticMode={staticMode} delay={0.27}><h2>把需求变成<br /><em>可验证的任务</em></h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.48}><p>这页适合在方案开始前说明试点边界，让业务、产品和技术团队对同一件事达成共识。</p></Reveal>
      </div>
      <div className="brief-fields">{fields.map(([label, value], i) => <Reveal staticMode={staticMode} from="right" delay={0.32 + i * 0.13} className="brief-field" key={label}>
        <span>{label}</span><strong>{value}</strong>
      </Reveal>)}</div>
      <TinyIndex number={8} />
    </section>
  )
}

function QuestionsAndAnswers({ staticMode }: SlideProps) {
  const rows = [
    ['01', '为什么先做小范围试点？', '范围清楚，才能看见流程变化，并及时处理现场反馈。'],
    ['02', '哪些信息需要先准备？', '确认可用数据、知识来源，以及谁负责更新和审核。'],
    ['03', '何时进入下一阶段？', '当效果、稳定性和使用意愿都得到验证，再扩大应用范围。'],
  ]
  return (
    <section className="slide slide-questions">
      <div className="slide-header slide-header--dark"><Brand compact /><span>Q & A / 问答说明</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>关键问题，直接回答</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.25}><p className="questions-intro">适合回应决策者最关心的实施条件与推进节奏。</p></Reveal>
      <div className="questions-list">{rows.map(([no, question, answer], i) => <Reveal staticMode={staticMode} delay={0.35 + i * 0.15} className="question-row" key={no}>
        <span>{no}</span><h3>{question}</h3><p>{answer}</p>
      </Reveal>)}</div>
      <TinyIndex number={9} />
    </section>
  )
}

function PriorityMatrix({ staticMode }: SlideProps) {
  const quadrants = [
    ['补足条件', '价值明确，但需要先解决数据或流程问题。'],
    ['优先试点', '价值明确，实施条件也已具备。'],
    ['持续观察', '目标和基础仍不清楚，暂时不投入开发。'],
    ['小范围验证', '条件较成熟，先验证实际使用价值。'],
  ]
  return (
    <section className="slide slide-matrix">
      <div className="slide-header slide-header--light"><Brand light compact /><span>PRIORITY MATRIX / 四象限</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>场景优先级</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.28}><p className="matrix-intro">用业务价值和实施准备度讨论投入顺序。</p></Reveal>
      <div className="matrix-y">业务价值</div>
      <span className="matrix-level matrix-level--high">高</span><span className="matrix-level matrix-level--low">低</span>
      <div className="matrix-grid">{quadrants.map(([title, body], i) => <Reveal staticMode={staticMode} delay={0.37 + i * 0.12} className={`matrix-quadrant matrix-quadrant--${i}`} key={title}>
        <span>0{i + 1}</span><h3>{title}</h3><p>{body}</p>
      </Reveal>)}</div>
      <div className="matrix-x"><span>准备度低</span><strong>实施准备度</strong><span>准备度高</span></div>
      <TinyIndex number={10} light />
    </section>
  )
}

function EvidenceChain({ staticMode }: SlideProps) {
  const rows = [
    ['观察', '一线人员重复查找同类信息', '先记录问题出现的位置与频率。'],
    ['判断', '知识入口分散，版本难以确认', '明确哪些内容需要统一管理。'],
    ['行动', '建立可信知识入口并开展试点', '用实际使用反馈修正内容和流程。'],
  ]
  return (
    <section className="slide slide-evidence">
      <div className="slide-header slide-header--dark"><Brand compact /><span>REASONING / 观察、判断、行动</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>让每个结论都有依据</h2></Reveal>
      <div className="evidence-rows">{rows.map(([label, point, detail], i) => <Reveal staticMode={staticMode} delay={0.29 + i * 0.16} className="evidence-row" key={label}>
        <span>0{i + 1} / {label}</span><h3>{point}</h3><p>{detail}</p>
      </Reveal>)}</div>
      <TinyIndex number={11} />
    </section>
  )
}

function PartnerPerspective({ staticMode }: SlideProps) {
  const rows = [0, 1, 2, 3]
  return (
    <section className="slide slide-partner-perspective">
      <div className="slide-header slide-header--dark"><Brand compact /><span>PARTNER NETWORK / 合作生态</span></div>
      <div className="partner-perspective__heading">
        <img className="partner-laurel partner-laurel--left" src={partnerLaurel} alt="" />
        <Reveal staticMode={staticMode} delay={0.13} className="partner-perspective__title"><span>携手行业伙伴</span><h2>共建产业 AI 应用生态</h2></Reveal>
        <img className="partner-laurel partner-laurel--right" src={partnerLaurel} alt="" />
      </div>
      <div className="partner-perspective__haze" />
      <div className="partner-floor">
        {rows.map((row) => <div className={`partner-floor__row partner-floor__row--${row}`} key={row}>
          {partnerLogos.slice(row * 5, row * 5 + 5).map((partner, index) => <Reveal staticMode={staticMode} delay={0.25 + row * 0.13 + index * 0.035} className="partner-floor__tile" key={partner.mark}><PartnerMark partner={partner} index={row * 5 + index} /></Reveal>)}
        </div>)}
      </div>
      <PartnerDisclaimer /><TinyIndex number={14} />
    </section>
  )
}

function PartnerOrbit({ staticMode }: SlideProps) {
  const positions = [
    [180, 135], [395, 65], [640, 95], [860, 165], [135, 385], [405, 315],
    [830, 360], [170, 680], [410, 750], [635, 695], [860, 650],
  ]
  return (
    <section className="slide slide-partner-orbit">
      <div className="slide-header slide-header--dark"><Brand compact /></div>
      <div className="partner-orbit__copy">
        <Reveal staticMode={staticMode} delay={0.1}><h2>合作伙伴</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.2} className="partner-orbit__english">Cooperating Enterprises</Reveal>
        <div className="partner-orbit__underline" />
        <Reveal staticMode={staticMode} delay={0.34}><p>面向工业智能化场景，连接企业、技术平台与专业团队。通过开放协作，让技术能力更快进入真实业务。</p></Reveal>
        <div className="partner-orbit__stats"><div><strong>XXX+</strong><span>企业伙伴</span></div><div><strong>XX+</strong><span>相关行业</span></div></div>
      </div>
      <div className="partner-orbit__stage">
        <div className="partner-orbit__ring partner-orbit__ring--outer" /><div className="partner-orbit__ring partner-orbit__ring--middle" /><div className="partner-orbit__ring partner-orbit__ring--inner" />
        <span className="partner-orbit__dot partner-orbit__dot--one" /><span className="partner-orbit__dot partner-orbit__dot--two" /><span className="partner-orbit__dot partner-orbit__dot--three" />
        <div className="partner-orbit__core">合作<br />伙伴</div>
        {positions.map(([x, y], index) => <Reveal staticMode={staticMode} delay={0.22 + index * 0.055} className="partner-orbit__node" key={partnerLogos[index].mark}>
          <div style={{ left: x, top: y }}><PartnerMark partner={partnerLogos[index]} index={index} /></div>
        </Reveal>)}
      </div>
      <PartnerDisclaimer /><TinyIndex number={15} />
    </section>
  )
}

function PartnerLogoGrid({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-partner-grid">
      <div className="partner-grid__left">
        <Brand light compact />
        <Reveal staticMode={staticMode} delay={0.12}><h2>合作伙伴</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.3}><p>面向产业场景，连接企业、平台与专业团队，形成可持续协作的生态网络。</p></Reveal>
        <div className="partner-grid__stats"><div><strong>XXX+</strong><span>企业伙伴</span></div><div><strong>XX+</strong><span>相关行业</span></div></div>
      </div>
      <div className="partner-grid__board">{partnerLogos.slice(0, 16).map((partner, index) => <Reveal staticMode={staticMode} delay={0.24 + index * 0.035} className="partner-grid__cell" key={partner.mark}><PartnerMark partner={partner} index={index} /></Reveal>)}</div>
      <PartnerDisclaimer light /><TinyIndex number={16} light />
    </section>
  )
}

function PartnerColumns({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-partner-columns">
      <div className="slide-header slide-header--dark"><Brand compact /></div>
      <div className="partner-columns__copy">
        <Reveal staticMode={staticMode} delay={0.26}><h2>合作伙伴</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.48}><p>以行业、技术与交付角色组织伙伴信息，展示一个项目背后的协作网络。</p></Reveal>
        <div className="partner-columns__stats"><div><strong>XXX+</strong><span>企业伙伴</span></div><div><strong>XX+</strong><span>相关行业</span></div></div>
      </div>
      <div className="partner-columns__rack">{[0, 1, 2, 3].map((column) => <Reveal staticMode={staticMode} from="right" delay={0.24 + column * 0.11} className={`partner-columns__column partner-columns__column--${column}`} key={column}>
        {partnerLogos.slice(column * 5, column * 5 + 5).map((partner, index) => <div className="partner-columns__logo" key={partner.mark}><PartnerMark partner={partner} index={column * 5 + index} /></div>)}
      </Reveal>)}</div>
      <PartnerDisclaimer /><TinyIndex number={17} />
    </section>
  )
}

function ResearchPartners({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-research-partners">
      <div className="slide-header slide-header--dark"><Brand compact /><span>R&D PARTNERS / 技术协作</span></div>
      <Reveal staticMode={staticMode} delay={0.12} className="research-partners__heading"><h2>技术研发伙伴</h2><p>以技术协作连接研究与产业应用</p></Reveal>
      <div className="research-partners__logos">{partnerLogos.slice(0, 18).map((partner, index) => <Reveal staticMode={staticMode} delay={0.28 + index * 0.035} className="research-partners__logo" key={partner.mark}><PartnerMark partner={partner} index={index} /></Reveal>)}</div>
      <div className="research-partners__globe" aria-hidden="true" />
      <PartnerDisclaimer /><TinyIndex number={18} />
    </section>
  )
}

function SingleImage({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-single-image">
      <motion.div className="single-image__photo" style={{ backgroundImage: `url(${controlRoom})` }} initial={staticMode ? false : { scale: 1.08, opacity: 0.5 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }} />
      <div className="single-image__shade" />
      <div className="slide-header slide-header--light"><Brand light compact /><span>FULL BLEED IMAGE / 单图展示</span></div>
      <div className="single-image__copy">
        <Reveal staticMode={staticMode} delay={0.2} className="eyebrow eyebrow--light">场景视觉 / IMAGE STORY</Reveal>
        <Reveal staticMode={staticMode} delay={0.39}><h2>让现场数据<br />成为行动依据</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.67}><p>适合展示产品主视觉、团队合照或案例现场。</p></Reveal>
      </div>
      <div className="single-image__caption">概念场景图 / 使用时替换为授权图片</div>
      <TinyIndex number={9} light />
    </section>
  )
}

function ImageGallery({ staticMode }: SlideProps) {
  const items = [
    { image: engineerTeam, title: '团队协作', detail: '交流业务问题与现场知识', className: 'gallery-tile--large' },
    { image: industrialRobot, title: '智能生产', detail: '连接设备、数据与流程', className: 'gallery-tile--top' },
    { image: controlRoom, title: '运行洞察', detail: '让关键变化被及时看见', className: 'gallery-tile--bottom' },
  ]
  return (
    <section className="slide slide-gallery">
      <div className="slide-header slide-header--dark"><Brand compact /><span>PHOTO GALLERY / 多图拼接</span></div>
      <Reveal staticMode={staticMode} delay={0.12}><h2>同一主题，三个观察角度</h2></Reveal>
      <div className="gallery-grid">
        {items.map(({ image, title, detail, className }, i) => <motion.div key={title} className={`gallery-tile ${className}`} initial={staticMode ? false : { opacity: 0, y: 48 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.28 + i * 0.16, ease: [0.22, 1, 0.36, 1] }}>
          <img src={image} alt={title} /><div className="gallery-tile__shade" /><div className="gallery-tile__caption"><strong>{title}</strong><span>{detail}</span></div>
        </motion.div>)}
      </div>
      <span className="gallery-note">概念场景图 / 可替换为项目案例与团队照片</span>
      <TinyIndex number={10} />
    </section>
  )
}

function ProductShowcase({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-product">
      <div className="slide-header slide-header--dark"><Brand compact /><span>PRODUCT SCREENSHOT / 界面展示</span></div>
      <div className="product-copy">
        <Reveal staticMode={staticMode} delay={0.14} className="eyebrow">产品与案例</Reveal>
        <Reveal staticMode={staticMode} delay={0.27}><h2>把产品界面<br />放进业务语境</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.53}><p>让观众先理解界面解决什么问题，再看功能细节与真实操作。</p></Reveal>
        <Reveal staticMode={staticMode} delay={0.7} className="product-copy__foot"><span>01</span>真实界面截图<span>→</span>关键功能说明</Reveal>
      </div>
      <motion.div className="product-window" initial={staticMode ? false : { opacity: 0, x: 90, rotateY: -6 }} animate={{ opacity: 1, x: 0, rotateY: 0 }} transition={{ duration: 1.1, delay: 0.16, ease: [0.22, 1, 0.36, 1] }}>
        <div className="product-window__bar"><span /><span /><span /><em>AUTO SPACE / PRODUCT PREVIEW</em></div>
        <img src={productUiDemo} alt="凹凸时空品牌 UI 工作台示意界面" />
      </motion.div>
      <span className="product-note">品牌 UI 演示界面 / 非实际产品数据</span>
      <TinyIndex number={11} />
    </section>
  )
}

// Replace each `src` below with a licensed project photo; captions are example copy.
function PictureOne({ staticMode }: SlideProps) {
  return <section className="slide slide-picture-one">
    <div className="slide-header slide-header--dark"><Brand compact /><span>PHOTO STORY / 01 IMAGE</span></div>
    <Reveal staticMode={staticMode} delay={0.14} className="picture-one__copy">
      <span className="eyebrow">一图 / 重点叙事</span>
      <h2>从一个现场<br />看见改变</h2>
      <p>用一张有明确主体的照片承载核心观点。正文只回答：眼前发生了什么，为什么值得关注。</p>
      <div className="picture-one__takeaway"><b>主张</b><strong>让现场信号进入日常决策。</strong></div>
    </Reveal>
    <motion.figure className="picture-one__figure" initial={staticMode ? false : { opacity: 0, x: 70, scale: 1.04 }} animate={{ opacity: 1, x: 0, scale: 1 }} transition={{ duration: 1.05, delay: 0.16, ease: [0.22, 1, 0.36, 1] }}>
      <img src={photoSmartFactory} alt="智能制造工厂示意图" />
      <figcaption><span>01 / 工业现场</span><strong>把真实场景作为叙事起点</strong></figcaption>
    </motion.figure>
    <span className="picture-note">概念场景图 / 请替换为已授权的真实项目照片</span><TinyIndex number={30} />
  </section>
}

function PictureTwo({ staticMode }: SlideProps) {
  const items = [
    { image: photoVisionInspection, no: '01', title: '识别', detail: '先让设备状态与质量变化可被看见。' },
    { image: photoEngineers, no: '02', title: '判断', detail: '再让现场人员基于同一份信息协作。' },
  ]
  return <section className="slide slide-picture-two">
    <div className="slide-header slide-header--light"><Brand light compact /><span>PHOTO STORY / 02 IMAGES</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="picture-heading picture-heading--light"><span className="eyebrow eyebrow--light">二图 / 对照说明</span><h2>同一个问题的两个视角</h2><p>左图放现场细节，右图放人的工作方式；两句说明点明关联。</p></Reveal>
    <div className="picture-two__pair">{items.map((item, index) => <Reveal staticMode={staticMode} delay={0.3 + index * 0.16} className="picture-two__item" key={item.no}>
      <div className="picture-two__image"><img src={item.image} alt={`${item.title}场景示意图`} /></div>
      <div className="picture-two__caption"><span>{item.no}</span><div><h3>{item.title}</h3><p>{item.detail}</p></div></div>
    </Reveal>)}</div>
    <span className="picture-note picture-note--light">概念场景图 / 可替换为改造前后、两个团队或两种解决路径</span><TinyIndex number={31} light />
  </section>
}

function PictureThree({ staticMode }: SlideProps) {
  const items = [
    { image: photoWarehouse, no: '01', title: '物流调度', detail: '把移动设备与库存状态放在同一视野。' },
    { image: photoMaintenance, no: '02', title: '设备维护', detail: '从异常信号追溯到具体部件。' },
    { image: photoEnergyRoom, no: '03', title: '运行监测', detail: '将关键变化交给合适的处理人。' },
  ]
  return <section className="slide slide-picture-three">
    <div className="slide-header slide-header--dark"><Brand compact /><span>PHOTO STORY / 03 IMAGES</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="picture-heading"><span className="eyebrow">三图 / 并列观察</span><h2>三个场景，讲清同一能力</h2><p>适合把一项能力在不同业务中的用法并列呈现。</p></Reveal>
    <div className="picture-three__columns">{items.map((item, index) => <Reveal staticMode={staticMode} delay={0.28 + index * 0.13} className="picture-three__column" key={item.no}>
      <div className="picture-three__image"><img src={item.image} alt={`${item.title}场景示意图`} /></div>
      <span>{item.no} / 场景</span><h3>{item.title}</h3><p>{item.detail}</p>
    </Reveal>)}</div>
    <span className="picture-note">概念场景图 / 正式使用时替换为已核实的业务影像</span><TinyIndex number={32} />
  </section>
}

function PictureFour({ staticMode }: SlideProps) {
  const items = [
    { image: industrialRobot, label: '生产', detail: '设备状态' },
    { image: controlRoom, label: '运行', detail: '过程监测' },
    { image: photoVisionInspection, label: '质量', detail: '视觉检测' },
    { image: engineerTeam, label: '协作', detail: '现场沟通' },
  ]
  return <section className="slide slide-picture-four">
    <div className="slide-header slide-header--dark"><Brand compact /><span>PHOTO STORY / 04 IMAGES</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="picture-heading"><span className="eyebrow">四图 / 案例矩阵</span><h2>用四个画面概览项目</h2><p>图片呈现范围，右侧文字说明它们如何构成完整项目。</p></Reveal>
    <div className="picture-four__grid">{items.map((item, index) => <Reveal staticMode={staticMode} delay={0.3 + index * 0.08} className="picture-four__tile" key={item.label}>
      <img src={item.image} alt={`${item.label}场景示意图`} /><div><b>{item.label}</b><span>{item.detail}</span></div>
    </Reveal>)}</div>
    <Reveal staticMode={staticMode} delay={0.55} className="picture-four__aside"><span>PROJECT VIEW</span><h3>不把项目讲成孤立的功能点</h3><p>从生产到质量，再到运行和协作，四张图帮助观众理解一项解决方案覆盖的现场环节。</p><strong>一页看全局</strong></Reveal>
    <span className="picture-note">概念场景图 / 可换成同一项目的四个真实环节</span><TinyIndex number={33} />
  </section>
}

function PictureFive({ staticMode }: SlideProps) {
  const details = [
    { image: photoEngineers, title: '访谈' },
    { image: photoVisionInspection, title: '采集' },
    { image: photoMaintenance, title: '验证' },
    { image: photoWarehouse, title: '运行' },
  ]
  return <section className="slide slide-picture-five">
    <div className="slide-header slide-header--light"><Brand light compact /><span>PHOTO STORY / 05 IMAGES</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="picture-heading picture-heading--light"><span className="eyebrow eyebrow--light">五图 / 主图与细节</span><h2>一个项目，五个关键镜头</h2><p>大图建立场景，小图补充执行细节；适合案例复盘与项目介绍。</p></Reveal>
    <motion.figure className="picture-five__hero" initial={staticMode ? false : { opacity: 0, y: 35 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.28 }}><img src={photoEnergyRoom} alt="工业能源运行中心示意图" /><figcaption><span>项目主视觉</span><strong>让整体场景先被看见</strong></figcaption></motion.figure>
    <div className="picture-five__details">{details.map((item, index) => <Reveal staticMode={staticMode} delay={0.42 + index * 0.09} className="picture-five__detail" key={item.title}><img src={item.image} alt={`${item.title}环节示意图`} /><span>{String(index + 1).padStart(2, '0')} / {item.title}</span></Reveal>)}</div>
    <span className="picture-note picture-note--light">概念场景图 / 主图与细节图均需替换为真实项目影像</span><TinyIndex number={34} light />
  </section>
}

function PictureSix({ staticMode }: SlideProps) {
  const items = [
    { image: photoSmartFactory, title: '生产现场', detail: '定义真实问题' },
    { image: photoVisionInspection, title: '质量检测', detail: '识别关键变化' },
    { image: photoEngineers, title: '现场共创', detail: '明确可执行路径' },
    { image: photoWarehouse, title: '物流协同', detail: '连接移动设备' },
    { image: photoMaintenance, title: '设备维护', detail: '追踪异常原因' },
    { image: photoEnergyRoom, title: '运行复盘', detail: '让反馈进入下一轮' },
  ]
  return <section className="slide slide-picture-six">
    <div className="slide-header slide-header--dark"><Brand compact /><span>PHOTO STORY / 06 IMAGES</span></div>
    <Reveal staticMode={staticMode} delay={0.12} className="picture-heading"><span className="eyebrow">六图 / 场景索引</span><h2>六个场景，快速建立全貌</h2><p>适合产品能力总览、项目纪实或章节开场。</p></Reveal>
    <div className="picture-six__grid">{items.map((item, index) => <Reveal staticMode={staticMode} delay={0.23 + index * 0.07} className="picture-six__tile" key={item.title}><div className="picture-six__image"><img src={item.image} alt={`${item.title}示意图`} /><span>{String(index + 1).padStart(2, '0')}</span></div><div className="picture-six__caption"><h3>{item.title}</h3><p>{item.detail}</p></div></Reveal>)}</div>
    <span className="picture-note">概念场景图 / 每格可独立替换图片与说明</span><TinyIndex number={35} />
  </section>
}

function LineChart({ staticMode }: SlideProps) {
  const points = [[80, 390], [275, 350], [470, 300], [665, 245], [860, 156], [1055, 112]]
  const line = `M ${points.map(([x, y]) => `${x} ${y}`).join(' L ')}`
  const area = `${line} L 1055 450 L 80 450 Z`
  return (
    <section className="slide slide-line-chart">
      <div className="slide-header slide-header--dark"><Brand compact /><span>DATA STORY / 折线图</span></div>
      <Reveal staticMode={staticMode} delay={0.14}><h2>用趋势解释变化</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.32}><p className="line-chart__intro">适合展示连续周期的增长、效率或使用情况。</p></Reveal>
      <div className="line-chart__plot">
        <div className="line-chart__axis"><span>80</span><span>60</span><span>40</span><span>20</span><span>0</span></div>
        <svg viewBox="0 0 1130 520" preserveAspectRatio="none" role="img" aria-label="示例折线趋势图">
          <defs><linearGradient id="line-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#0D7CFD" stopOpacity=".24" /><stop offset="100%" stopColor="#0D7CFD" stopOpacity="0" /></linearGradient></defs>
          {[40, 140, 240, 340, 440].map((y) => <line key={y} x1="80" y1={y} x2="1055" y2={y} stroke="#D7E4F0" strokeWidth="1" />)}
          <path d={area} fill="url(#line-fill)" />
          <motion.path d={line} fill="none" stroke="#0D7CFD" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" initial={staticMode ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.7, delay: 0.38, ease: 'easeInOut' }} />
          {points.map(([x, y], i) => <motion.circle key={i} cx={x} cy={y} r="10" fill="#fff" stroke="#0D7CFD" strokeWidth="5" initial={staticMode ? false : { opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.35, delay: 0.5 + i * 0.23 }} />)}
        </svg>
        <div className="line-chart__labels"><span>01月</span><span>02月</span><span>03月</span><span>04月</span><span>05月</span><span>06月</span></div>
      </div>
      <div className="line-chart__callout"><span>+ TREND</span><strong>连续改善</strong><p>结论先行，图表负责提供证据。</p></div>
      <div className="sample-note sample-note--dark">* 演示数据，正式使用时请替换为已核实指标</div>
      <TinyIndex number={17} />
    </section>
  )
}

function DonutChart({ staticMode }: SlideProps) {
  const radius = 210
  const circumference = 2 * Math.PI * radius
  const groups = [
    { value: 46, label: '高优先级', color: '#0D7CFD', desc: '明确价值与实施条件' },
    { value: 34, label: '中优先级', color: '#61ADFF', desc: '需要补充数据或流程' },
    { value: 20, label: '持续观察', color: '#B7D9F7', desc: '等待场景更加成熟' },
  ]
  let cumulative = 0
  return (
    <section className="slide slide-donut-chart">
      <div className="slide-header slide-header--light"><Brand light compact /><span>DATA STORY / 环形图</span></div>
      <Reveal staticMode={staticMode} delay={0.13}><h2>把结构讲清楚</h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.3}><p className="donut-chart__intro">适合展示组成比例与优先级分布。</p></Reveal>
      <div className="donut-chart__legend">
        {groups.map((group, i) => <Reveal staticMode={staticMode} delay={0.43 + i * 0.13} className="donut-chart__legend-row" key={group.label}>
          <span className="donut-chart__swatch" style={{ background: group.color }} /><strong>{group.label}</strong><em>{group.value}%</em><p>{group.desc}</p>
        </Reveal>)}
      </div>
      <div className="donut-chart__visual">
        <svg viewBox="0 0 640 640" role="img" aria-label="示例环形图，三组比例为46%、34%、20%">
          <circle cx="320" cy="320" r={radius} fill="none" stroke="#21416C" strokeWidth="76" />
          {groups.map((group, i) => {
            const length = group.value / 100 * circumference
            const offset = -cumulative / 100 * circumference
            cumulative += group.value
            return <motion.circle key={group.label} cx="320" cy="320" r={radius} fill="none" stroke={group.color} strokeWidth="76" transform="rotate(-90 320 320)" strokeDashoffset={offset} initial={staticMode ? false : { strokeDasharray: `0 ${circumference}` }} animate={{ strokeDasharray: `${length} ${circumference}` }} transition={{ duration: 1.05, delay: 0.36 + i * 0.24, ease: [0.22, 1, 0.36, 1] }} />
          })}
        </svg>
        <div className="donut-chart__center"><span>SCENARIO MIX</span><strong>100<span>%</span></strong><small>示例结构</small></div>
      </div>
      <div className="sample-note">* 演示数据，正式使用时请替换为实际分类与比例</div>
      <TinyIndex number={18} light />
    </section>
  )
}

function PieChart({ staticMode }: SlideProps) {
  const segments = [
    ['46%', '核心场景', '优先实施', '#0D7CFD'],
    ['34%', '拓展场景', '分步验证', '#61ADFF'],
    ['20%', '储备场景', '持续观察', '#B7D9F7'],
  ]
  return (
    <section className="slide slide-pie-chart">
      <div className="slide-header slide-header--dark"><Brand compact /><span>DATA STORY / 饼图</span></div>
      <Reveal staticMode={staticMode} delay={0.13} className="eyebrow">比例与构成</Reveal>
      <Reveal staticMode={staticMode} delay={0.26}><h2>让占比<br /><em>一目了然</em></h2></Reveal>
      <Reveal staticMode={staticMode} delay={0.52}><p className="pie-chart__intro">适合说明资源投入、场景分类或客户结构。</p></Reveal>
      <motion.div className="pie-chart__visual" initial={staticMode ? false : { scale: 0.78, rotate: -42, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} transition={{ duration: 1.2, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}>
        <div className="pie-chart__circle" />
      </motion.div>
      <div className="pie-chart__legend">{segments.map(([value, title, detail, color], i) => <Reveal staticMode={staticMode} delay={0.5 + i * 0.14} className="pie-chart__row" key={title}>
        <span className="pie-chart__swatch" style={{ background: color }} /><strong>{value}</strong><div><h3>{title}</h3><p>{detail}</p></div>
      </Reveal>)}</div>
      <div className="sample-note sample-note--dark">* 演示数据，正式使用时请替换为实际分类与比例</div>
      <TinyIndex number={19} />
    </section>
  )
}

function Summary({ staticMode }: SlideProps) {
  const items = [
    ['01', '从问题出发', '识别真实业务场景，明确预期改善。'],
    ['02', '用试点验证', '把方案放入流程，用结果支持判断。'],
    ['03', '向长期运行', '让能力可维护、可协作、可持续优化。'],
  ]
  return (
    <section className="slide slide-summary">
      <div className="slide-header slide-header--dark"><Brand compact /><span>SUMMARY / 核心结论</span></div>
      <Reveal staticMode={staticMode} delay={0.14} className="eyebrow">核心观点回顾</Reveal>
      <Reveal staticMode={staticMode} delay={0.29}><h2>让 AI 落地，<br /><em>关键是形成闭环。</em></h2></Reveal>
      <div className="summary-grid">{items.map(([no, title, body], i) => <Reveal staticMode={staticMode} delay={0.43 + i * 0.14} className="summary-item" key={no}>
        <span>{no}</span><h3>{title}</h3><p>{body}</p>
      </Reveal>)}</div>
      <TinyIndex number={21} />
    </section>
  )
}

function Contact({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-contact">
      <div className="slide-contact__glow" />
      <div className="slide-header slide-header--light"><Brand light compact /><span>CONTACT / 联系方式</span></div>
      <div className="contact-copy">
        <Reveal staticMode={staticMode} delay={0.15} className="eyebrow eyebrow--light">下一步 / NEXT STEP</Reveal>
        <Reveal staticMode={staticMode} delay={0.3}><h2>从一个真实问题，<br />开始一次对话。</h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.56}><p>带着你的业务场景与目标，与我们一起讨论可行的 AI 路径。</p></Reveal>
      </div>
      <div className="contact-details">
        <Reveal staticMode={staticMode} delay={0.7}><span>CONTACT PERSON</span><strong>请填写联系人</strong></Reveal>
        <Reveal staticMode={staticMode} delay={0.83}><span>EMAIL / PHONE</span><strong>请填写邮箱与电话</strong></Reveal>
      </div>
      <span className="contact-placeholder">模板占位信息 · 对外发送前请替换</span>
      <TinyIndex number={22} light />
    </section>
  )
}

function Closing({ staticMode }: SlideProps) {
  return (
    <section className="slide slide-closing" style={{ backgroundImage: `url(${blueRibbon})` }}>
      <div className="slide-closing__shade" />
      <div className="slide-closing__top"><Brand light /><span>THANK YOU</span></div>
      <div className="slide-closing__copy">
        <Reveal staticMode={staticMode} delay={0.18} className="eyebrow eyebrow--light">凹凸时空 / AUTO SPACE</Reveal>
        <Reveal staticMode={staticMode} delay={0.32}><h2>一起，让 AI<br /><em>改变行业未来</em></h2></Reveal>
        <Reveal staticMode={staticMode} delay={0.64}><p>期待与你讨论真实业务中的下一步。</p></Reveal>
      </div>
      <TinyIndex number={23} light />
    </section>
  )
}

export const slides: SlideDefinition[] = [
  { id: 'cover', title: '封面', category: '开场', dark: true, component: Cover },
  { id: 'agenda', title: '目录', category: '开场', dark: false, component: Agenda },
  { id: 'section', title: '章节页', category: '开场', dark: true, component: SectionOne },
  { id: 'statement', title: '核心观点', category: '论述', dark: false, component: Statement },
  { id: 'plain-content', title: '普通正文', category: '内容', dark: false, component: PlainContent },
  { id: 'bullet-content', title: '要点列表', category: '内容', dark: false, component: BulletContent },
  { id: 'editorial-split', title: '双栏论述', category: '内容', dark: false, component: EditorialSplit },
  { id: 'project-brief', title: '项目简报', category: '内容', dark: false, component: ProjectBrief },
  { id: 'questions-answers', title: '问答说明', category: '内容', dark: false, component: QuestionsAndAnswers },
  { id: 'priority-matrix', title: '四象限', category: '内容', dark: true, component: PriorityMatrix },
  { id: 'evidence-chain', title: '观察与判断', category: '内容', dark: false, component: EvidenceChain },
  { id: 'photo', title: '图文叙事', category: '论述', dark: false, component: PhotoStory },
  { id: 'capabilities', title: '三项能力', category: '论述', dark: false, component: Capabilities },
  { id: 'partner-perspective', title: '透视 Logo 墙', category: '合作', dark: false, component: PartnerPerspective },
  { id: 'partner-orbit', title: '环绕合作生态', category: '合作', dark: false, component: PartnerOrbit },
  { id: 'partner-grid', title: '合作伙伴矩阵', category: '合作', dark: true, component: PartnerLogoGrid },
  { id: 'partner-columns', title: '立体 Logo 竖列', category: '合作', dark: false, component: PartnerColumns },
  { id: 'research-partners', title: '技术研发伙伴', category: '合作', dark: false, component: ResearchPartners },
  { id: 'single-image', title: '单图展示', category: '图片', dark: true, component: SingleImage },
  { id: 'image-gallery', title: '多图拼接', category: '图片', dark: false, component: ImageGallery },
  { id: 'product-showcase', title: '界面展示', category: '图片', dark: false, component: ProductShowcase },
  { id: 'process', title: '流程', category: '方案', dark: true, component: Process },
  { id: 'architecture', title: '方案架构', category: '方案', dark: false, component: Architecture },
  { id: 'logic-argument', title: '论证链', category: '逻辑图', dark: false, component: LogicArgument },
  { id: 'logic-tree', title: '决策树', category: '逻辑图', dark: false, component: LogicDecisionTree },
  { id: 'logic-cause', title: '因果拆解', category: '逻辑图', dark: true, component: LogicCauseMap },
  { id: 'logic-loop', title: '迭代闭环', category: '逻辑图', dark: false, component: LogicLoop },
  { id: 'logic-funnel', title: '漏斗筛选', category: '逻辑图', dark: false, component: LogicFunnel },
  { id: 'logic-swimlane', title: '泳道协作', category: '逻辑图', dark: false, component: LogicSwimlane },
  { id: 'picture-one', title: '一图叙事', category: '图文模板', dark: false, component: PictureOne },
  { id: 'picture-two', title: '二图对照', category: '图文模板', dark: true, component: PictureTwo },
  { id: 'picture-three', title: '三图并列', category: '图文模板', dark: false, component: PictureThree },
  { id: 'picture-four', title: '四图矩阵', category: '图文模板', dark: false, component: PictureFour },
  { id: 'picture-five', title: '五图叙事', category: '图文模板', dark: true, component: PictureFive },
  { id: 'picture-six', title: '六图总览', category: '图文模板', dark: false, component: PictureSix },
  { id: 'metric', title: '大数据焦点', category: '数据', dark: true, component: Metric },
  { id: 'comparison', title: '前后对比', category: '方案', dark: true, component: Comparison },
  { id: 'chart', title: '柱状图', category: '数据', dark: false, component: Chart },
  { id: 'line-chart', title: '折线图', category: '数据', dark: false, component: LineChart },
  { id: 'donut-chart', title: '环形图', category: '数据', dark: true, component: DonutChart },
  { id: 'pie-chart', title: '饼图', category: '数据', dark: false, component: PieChart },
  { id: 'plan', title: '计划表', category: '方案', dark: false, component: Plan },
  { id: 'summary', title: '总结', category: '收尾', dark: false, component: Summary },
  { id: 'contact', title: '联系方式', category: '收尾', dark: true, component: Contact },
  { id: 'closing', title: '封底', category: '收尾', dark: true, component: Closing },
]


