import fs from 'node:fs'
import path from 'node:path'

const dist = path.resolve('dist')
let html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8')

html = html.replace(/<link rel="stylesheet" crossorigin href="\.\/([^\"]+)"\s*\/?\s*>/g, (_, asset) => {
  const css = fs.readFileSync(path.join(dist, asset), 'utf8')
  return `<style>${css}</style>`
})
html = html.replace(/<script type="module" crossorigin src="\.\/([^\"]+)"><\/script>/g, (_, asset) => {
  const js = fs.readFileSync(path.join(dist, asset), 'utf8').replaceAll('</script>', '<\\/script>')
  return `<script type="module">${js}</script>`
})

if (html.includes('src="./assets/') || html.includes('href="./assets/')) {
  throw new Error('Standalone HTML still references external assets')
}
const output = path.join(dist, 'auto-space-deck.html')
fs.writeFileSync(output, html)
console.log(`Standalone HTML: ${output} (${(fs.statSync(output).size / 1024 / 1024).toFixed(1)} MB)`)
