import fs from 'node:fs'

// Clean cubic Bézier leaves based on the arrangement in the supplied reference.
// Geometry is defined in vectors, so the emblem stays sharp at any export size.
const leafPairs = [
  [[27, 8], [22, 1], [39, 8]],
  [[23, 14], [17, 5], [37, 14]],
  [[19, 21], [12, 11], [34, 20]],
  [[15, 28], [8, 18], [31, 26]],
  [[12, 36], [5, 26], [28, 33]],
  [[10, 44], [3, 35], [25, 40]],
  [[10, 52], [2, 44], [23, 47]],
  [[12, 60], [3, 54], [23, 55]],
  [[16, 68], [5, 64], [25, 63]],
  [[21, 75], [9, 73], [28, 70]],
  [[27, 80], [15, 80], [31, 75]],
]

function leaf([bx, by], [tx, ty], width) {
  const dx = tx - bx
  const dy = ty - by
  const length = Math.hypot(dx, dy)
  const nx = -dy / length
  const ny = dx / length
  const point = (fraction, side) => [bx + dx * fraction + nx * width * side, by + dy * fraction + ny * width * side]
  const format = ([x, y]) => `${x.toFixed(2)} ${y.toFixed(2)}`
  return `M ${format([bx, by])} C ${format(point(.13, .48))} ${format(point(.62, 1))} ${format([tx, ty])} C ${format(point(.80, -.45))} ${format(point(.27, -.66))} ${format([bx, by])} Z`
}

const leaves = leafPairs.flatMap(([base, outer, inner], index) => [
  `<path d="${leaf(base, outer, index < 3 ? 2.8 : 3.6)}"/>`,
  `<path d="${leaf(base, inner, index < 3 ? 2.7 : 3.25)}"/>`,
])

const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 57 94" aria-hidden="true">
  <defs><linearGradient id="laurel-blue" x1="0" y1="0" x2=".2" y2="1"><stop offset="0" stop-color="#83b8eb"/><stop offset="1" stop-color="#3698e8"/></linearGradient></defs>
  <path d="M 29 3 C 17 15 8 29 9 48 C 10 65 19 79 34 86 C 41 90 48 91 54 91" fill="none" stroke="url(#laurel-blue)" stroke-width="1.15" stroke-linecap="round"/>
  <g fill="url(#laurel-blue)">${leaves.join('')}</g>
</svg>`

fs.writeFileSync('src/assets/partner-laurel.svg', svg, 'utf8')
console.log('Wrote src/assets/partner-laurel.svg')
