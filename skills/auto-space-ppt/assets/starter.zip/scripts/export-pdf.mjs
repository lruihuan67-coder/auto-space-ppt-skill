import path from 'node:path'
import { writeFile } from 'node:fs/promises'
import { pathToFileURL } from 'node:url'
import { PDFDocument } from 'pdf-lib'
import { chromium } from 'playwright-core'

const chrome = process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const htmlPath = path.resolve('dist/auto-space-deck.html')
const pdfPath = path.resolve('dist/凹凸时空-品牌演示模板.pdf')
const browser = await chromium.launch({ executablePath: chrome, headless: true, args: ['--allow-file-access-from-files'] })
try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 2 })
  await page.goto(`${pathToFileURL(htmlPath)}?print=1`, { waitUntil: 'load' })
  await page.waitForFunction(() => window.__DECK_READY__ === true, { timeout: 30000 })
  await page.emulateMedia({ media: 'print', reducedMotion: 'reduce' })
  await page.evaluate(() => document.fonts.ready)

  // JPEG pages use a single sRGB image each. This avoids transparency and
  // gradient-compositing differences between PDF viewers, including Codex.
  const document = await PDFDocument.create()
  document.setTitle('凹凸时空｜品牌演示模板')
  document.setAuthor('凹凸时空 · Auto Space')
  const slides = page.locator('.print-page')
  const count = await slides.count()
  if (count === 0) throw new Error('No print pages found')

  for (let index = 0; index < count; index += 1) {
    const jpeg = await slides.nth(index).screenshot({
      type: 'jpeg',
      quality: 94,
      animations: 'disabled',
      scale: 'device',
      timeout: 30000,
    })
    const image = await document.embedJpg(jpeg)
    const pdfPage = document.addPage([1200, 675])
    pdfPage.drawImage(image, { x: 0, y: 0, width: 1200, height: 675 })
    console.log(`Captured slide ${index + 1}/${count}`)
  }

  await writeFile(pdfPath, await document.save())
  console.log(`RGB PDF: ${pdfPath}`)
} finally {
  await browser.close()
}
