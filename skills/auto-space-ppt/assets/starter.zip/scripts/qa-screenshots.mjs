import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { chromium } from 'playwright-core'

const output = path.resolve('qa')
fs.mkdirSync(output, { recursive: true })
const browser = await chromium.launch({ executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, args: ['--allow-file-access-from-files'] })
try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1 })
  const errors = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.goto(pathToFileURL(path.resolve('dist/auto-space-deck.html')).href, { waitUntil: 'load' })
  await page.waitForFunction(() => window.__DECK_READY__ === true, { timeout: 30000 })
  for (let i = 1; i <= 45; i++) {
    if (i > 1) await page.keyboard.press('ArrowRight')
    await page.waitForTimeout(i === 1 ? 1400 : 1900)
    await page.screenshot({ path: path.join(output, `slide-${String(i).padStart(2, '0')}.png`) })
  }
  console.log(JSON.stringify({ screenshots: 45, errors }, null, 2))
} finally {
  await browser.close()
}
